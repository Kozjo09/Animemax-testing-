import {
  looksLikeBatch, hitsExclusion, buildQueries, searchContext,
  shapeAll, finalize, withEpisodeCandidates
} from './lib/shared.js'

const SOURCE_DEFAULT = 'high'

const BASE = 'https://feed.animetosho.org/json'
const MAPPING_URL = 'https://raw.githubusercontent.com/anh9000/anitorrent/main/data/anilist-to-anidb.json'

let mappingCache = null
let mappingPromise = null

function validId (v) {
  const n = Number(v)
  return Number.isInteger(n) && n > 0
}

async function getMapping () {
  if (mappingCache) return mappingCache
  if (!mappingPromise) {
    mappingPromise = (async () => {
      try {
        const r = await fetch(MAPPING_URL)
        if (!r.ok) return {}
        const data = await r.json()
        mappingCache = data && typeof data === 'object' ? data : {}
        return mappingCache
      } catch {
        return {}
      }
    })()
  }
  return mappingPromise
}

async function resolveAnidbAid (query) {
  if (validId(query.anidbAid)) return Number(query.anidbAid)
  if (!validId(query.anilistId)) return null
  const map = await getMapping()
  const aid = map[String(query.anilistId)]
  return validId(aid) ? Number(aid) : null
}

async function tryFetch (url) {
  let res
  try {
    res = await fetch(url)
  } catch (err) {
    throw new Error('Cannot reach AnimeTosho. Check your internet connection or try again later.')
  }
  if (!res.ok) {
    throw new Error('AnimeTosho returned HTTP ' + res.status + '. The site may be down or rate limiting your IP.')
  }
  let data
  try {
    data = await res.json()
  } catch (err) {
    throw new Error('AnimeTosho returned an unexpected response. The API may have changed.')
  }
  if (!Array.isArray(data)) return []
  return data
}

function toResult (item, accuracy) {
  const hash = String(item.info_hash || '').toLowerCase()
  if (!hash) return null
  return {
    title: item.title || item.torrent_name || '',
    link: item.magnet_uri || hash,
    hash,
    seeders: Number(item.seeders) || 0,
    leechers: Number(item.leechers) || 0,
    downloads: Number(item.torrent_downloaded_count) || 0,
    size: Number(item.total_size) || 0,
    date: item.timestamp ? new Date(item.timestamp * 1000) : new Date(),
    accuracy
  }
}

function dedupe (items) {
  const seen = new Set()
  const out = []
  for (const r of items) {
    if (!r || seen.has(r.hash)) continue
    seen.add(r.hash)
    out.push(r)
  }
  return out
}

async function fetchByEid (eid) {
  const items = await tryFetch(BASE + '?eid=' + encodeURIComponent(eid))
  return items.map(i => toResult(i, 'high')).filter(Boolean)
}

async function fetchByAid (aid) {
  const items = await tryFetch(BASE + '?aid=' + encodeURIComponent(aid))
  return items.map(i => toResult(i, 'high')).filter(Boolean)
}

// AnimeTosho's search endpoint is slow and serializes concurrent requests, so
// the query count is kept low and the episode-numbered round only runs when the
// plain titles did not already turn up the episode.
async function fetchByText (titles, episode, foundEpisode, anilistId) {
  const { bases, numbered } = buildQueries(titles, { limit: 2, episode, anilistId })
  const seen = new Map()
  const run = async qs => {
    const settled = await Promise.allSettled(qs.map(q => tryFetch(BASE + '?q=' + encodeURIComponent(q))))
    for (const s of settled) {
      if (s.status !== 'fulfilled') continue
      for (const i of s.value) {
        const r = toResult(i, 'medium')
        if (r && !seen.has(r.hash)) seen.set(r.hash, r)
      }
    }
  }
  await run(bases)
  if (numbered.length && !foundEpisode([...seen.values()])) await run(numbered)
  return [...seen.values()]
}

function classifyAndTag (raw, ctx) {
  const items = dedupe(raw).filter(r => !hitsExclusion(r.title, ctx.exclusions))
  const out = shapeAll(items, ctx, SOURCE_DEFAULT)
  if (ctx.mode === 'batch') {
    return out.filter(r => looksLikeBatch(r.title)).map(r => ({ ...r, type: 'batch', accuracy: 'low' }))
  }
  return out
}

async function search (query, mode) {
  if (!query) return []
  if (query.notAired) return []

  const ctx = searchContext(query, mode)
  const resolvedAid = await resolveAnidbAid(query)

  let raw = []

  if (mode === 'single' && validId(query.anidbEid)) {
    try { raw = await fetchByEid(query.anidbEid) } catch (_) { raw = [] }
  } else if (resolvedAid) {
    try { raw = await fetchByAid(resolvedAid) } catch (_) { raw = [] }
  }

  const results = classifyAndTag(raw, ctx)

  if (!results.some(r => r._tier === 'A') && (query.titles || []).length) {
    const seen = new Set(results.map(r => r.hash))
    const foundEpisode = items => classifyAndTag(items, ctx).some(r => r._tier === 'A')
    for (const r of classifyAndTag(await fetchByText(query.titles, query.episode, foundEpisode, query.anilistId), ctx)) {
      if (seen.has(r.hash)) continue
      seen.add(r.hash)
      results.push(r)
    }
  }

  return finalize(results, ctx)
}

export default new class AnimeTosho {
  async single (query) {
    if (query.episodeCount === 1) return search(query, 'movie')
    return search(await withEpisodeCandidates(query), 'single')
  }
  async batch (query) { return search(query, 'batch') }
  async movie (query) { return search(query, 'movie') }

  async test () {
    let res
    try {
      res = await fetch(BASE + '?q=test')
    } catch (err) {
      throw new Error('Cannot reach AnimeTosho. Check your internet connection or try again later.')
    }
    if (!res.ok) {
      throw new Error('AnimeTosho returned HTTP ' + res.status + '. The site may be down.')
    }
    return true
  }
}()
